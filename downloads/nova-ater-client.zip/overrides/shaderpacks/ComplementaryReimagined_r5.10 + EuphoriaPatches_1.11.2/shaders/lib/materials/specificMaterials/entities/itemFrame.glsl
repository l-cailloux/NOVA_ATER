noSmoothLighting = true;
