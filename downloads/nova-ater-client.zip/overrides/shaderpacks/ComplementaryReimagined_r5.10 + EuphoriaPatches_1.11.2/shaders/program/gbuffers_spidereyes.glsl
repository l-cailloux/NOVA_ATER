//////////////////////////////////////////
// Complementary Shaders by EminGT      //
// With Euphoria Patches by SpacEagle17 //
//////////////////////////////////////////

//Common//
#include "/lib/common.glsl"
//#define INTENSE_DEEP_DARK

#if defined MIRROR_DIMENSION || defined WORLD_CURVATURE
    #include "/lib/misc/distortWorld.glsl"
#endif

//////////Fragment Shader//////////Fragment Shader//////////Fragment Shader//////////
#ifdef FRAGMENT_SHADER

in vec2 texCoord;

in vec4 glColor;

//Pipeline Constants//

//Common Variables//

//Common Functions//

//Includes//
#ifdef COLOR_CODED_PROGRAMS
    #include "/lib/misc/colorCodedPrograms.glsl"
#endif

//Program//
void main() {
    vec4 color = texture2D(tex, texCoord) * glColor;

    #ifdef IS_IRIS
        color.rgb = pow1_5(color.rgb);

        if (entityId == 50008) { // Enderman
            color.rgb += vec3(0.1);
            color.rgb *= vec3(3.0, 1.5, 3.0);
        } else if (entityId == 50152) { // Warden
            #ifdef INTENSE_DEEP_DARK
                color.rgb += mix(0.0, 0.3, darknessFactor);
            #endif
            color.rgb *= 1.5 + 3.0 * color.g;
        }
    #else
        #ifdef INTENSE_DEEP_DARK
            if (color.b > 0.1 && color.r < 0.5) { // Warden
                color.rgb += mix(0.0, 0.3, darknessFactor);
            }
        #endif

        color.rgb = pow1_5(color.rgb) * (
            1.5
            + vec3(4.1, 3.0, 4.1) * (0.8 + 0.5 * color.g) * max0(color.r * color.b - color.g) // Tweak for Enderman
            + 5.0 * max0(color.g * color.b - color.r) // Tweak for Warden
            - 0.5 * sqrt(color.r * color.g * color.b) // Tweak for Breeze
            - vec3(0.0, 0.7, 0.7) * max0(color.r * color.g - color.b) // Tweak for Copper Golem
        );
    #endif

    #ifdef COLOR_CODED_PROGRAMS
        ColorCodeProgram(color, -1);
    #endif

    /* DRAWBUFFERS:06 */
    gl_FragData[0] = color;
    gl_FragData[1] = vec4(0, 0, 0, mix(color.a, 1.0, sqrt4(eyeBrightness.x / 240.0)));
}

#endif

//////////Vertex Shader//////////Vertex Shader//////////Vertex Shader//////////
#ifdef VERTEX_SHADER

out vec2 texCoord;

out vec4 glColor;

//Attributes//

#if defined ATLAS_ROTATION || defined WAVE_EVERYTHING
    attribute vec4 mc_midTexCoord;
    vec2 lmCoord = GetLightMapCoordinates();
#endif

//Common Variables//

//Common Functions//

//Includes//

#ifdef WAVE_EVERYTHING
    #include "/lib/materials/materialMethods/wavingBlocks.glsl"
#endif

//Program//
void main() {
    gl_Position = ftransform();

    texCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    #ifdef ATLAS_ROTATION
        texCoord += texCoord * float(hash33(mod(cameraPosition * 0.5, vec3(100.0))));
    #endif

    glColor = gl_Color;

    #if defined MIRROR_DIMENSION || defined WORLD_CURVATURE || defined WAVE_EVERYTHING
        vec4 position = gbufferModelViewInverse * gl_ModelViewMatrix * gl_Vertex;
        #ifdef MIRROR_DIMENSION
            doMirrorDimension(position);
        #endif
        #ifdef WORLD_CURVATURE
            position.y += doWorldCurvature(position.xz);
        #endif
        #ifdef WAVE_EVERYTHING
            DoWaveEverything(position.xyz);
        #endif
        gl_Position = gl_ProjectionMatrix * gbufferModelView * position;
    #endif

    #ifdef IS_IRIS
        // Some mods draw hand stuff in eyes to make it emissive, creates z-fighting :/
        if (renderStage == MC_RENDER_STAGE_HAND_SOLID || renderStage == MC_RENDER_STAGE_HAND_TRANSLUCENT) gl_Position.z -= 0.0001;
    #endif
}

#endif
